let capturedLogs = { console: [], network: [] };
let debugTabId = null;
const DEBUGGER_VERSION = "1.3";

// Initialize capturing state on install/startup
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ isCapturing: false });
});

// Main message listener
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'TOGGLE_CAPTURE') {
    handleToggleCapture(message.capture, message.tabId);
    sendResponse({ success: true });
  } else if (message.type === 'CONSOLE_LOG') {
    // We MUST check if the log is from the tab we are debugging,
    // because the content script now runs everywhere.
    if (sender.tab && sender.tab.id === debugTabId) {
      capturedLogs.console.push(message.payload);
    }
  } else if (message.type === 'GET_LOGS') {
    sendResponse({ data: capturedLogs });
  } else if (message.type === 'CLEAR_LOGS') {
    capturedLogs = { console: [], network: [] };
    sendResponse({ success: true });
  }
  return true; // Keep message channel open for async response
});

function handleToggleCapture(shouldCapture, tabId) {
  if (shouldCapture) {
    startCapturing(tabId);
  } else {
    stopCapturing();
  }
}

function startCapturing(tabId) {
  if (debugTabId) {
    console.warn("Already capturing. Stop first.");
    return;
  }
  debugTabId = tabId;
  capturedLogs = { console: [], network: [] }; // Reset logs

  console.log("Attaching debugger to tab:", debugTabId);
  chrome.debugger.attach({ tabId: debugTabId }, DEBUGGER_VERSION, () => {
    if (chrome.runtime.lastError) {
      console.error("Debugger attach error:", chrome.runtime.lastError.message);
      return;
    }
    console.log("Debugger attached. Enabling network domain.");
    chrome.debugger.sendCommand({ tabId: debugTabId }, "Network.enable");
  });
}

function stopCapturing() {
  if (!debugTabId) return;
  const tabToDetach = debugTabId;
  debugTabId = null;

  console.log("Detaching debugger from tab:", tabToDetach);
  chrome.debugger.detach({ tabId: tabToDetach }, () => {
    chrome.storage.local.set({ isCapturing: false });
  });
}

// --- ALL INJECTION LOGIC HAS BEEN REMOVED ---
// No injectContentScript function.
// No tabs.onUpdated listener to reinject.

// Listener for debugger events (network requests)
chrome.debugger.onEvent.addListener((source, method, params) => {
  if (source.tabId !== debugTabId) return;

  if (method === "Network.requestWillBeSent") {
    capturedLogs.network.push({
      type: 'request',
      requestId: params.requestId,
      url: params.request.url,
      method: params.request.method,
      timestamp: new Date().toISOString(),
    });
  } else if (method === "Network.responseReceived") {
    capturedLogs.network.push({
      type: 'response',
      requestId: params.requestId,
      status: params.response.status,
      timestamp: new Date().toISOString(),
    });
  }
});

// Clean up when the tab being debugged is closed
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === debugTabId) {
    stopCapturing();
  }
});