// popup.js

const toggleCaptureBtn = document.getElementById('toggleCaptureBtn');
const downloadBtn = document.getElementById('downloadBtn');
const copyLogBtn = document.getElementById('copyLogBtn');
const clearBtn = document.getElementById('clearBtn');
const statusDiv = document.getElementById('status');

// Helper to get the active tab
async function getCurrentTab() {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// Update UI based on stored state when popup opens
chrome.storage.local.get(['isCapturing'], (result) => {
  updateUI(result.isCapturing);
});

function updateUI(isCapturing) {
  if (isCapturing) {
    statusDiv.textContent = 'Status: Capturing...';
    toggleCaptureBtn.textContent = 'Stop Capturing';
    toggleCaptureBtn.style.backgroundColor = '#f44336';
  } else {
    statusDiv.textContent = 'Status: Idle';
    toggleCaptureBtn.textContent = 'Start Capturing';
    toggleCaptureBtn.style.backgroundColor = '#4CAF50';
  }
}

toggleCaptureBtn.addEventListener('click', async () => {
  const tab = await getCurrentTab();
  if (!tab) {
    alert("Could not find the active tab.");
    return;
  }

  chrome.storage.local.get(['isCapturing'], (result) => {
    const shouldCapture = !result.isCapturing;
    // Send message to background script to start/stop with the correct tab ID
    chrome.runtime.sendMessage({ type: 'TOGGLE_CAPTURE', capture: shouldCapture, tabId: tab.id }, () => {
      chrome.storage.local.set({ isCapturing: shouldCapture });
      updateUI(shouldCapture);
    });
  });
});

// ... (downloadBtn and clearBtn listeners remain the same) ...
downloadBtn.addEventListener('click', () => {
    // Request logs from the background script
    chrome.runtime.sendMessage({ type: 'GET_LOGS' }, (response) => {
        if (response && response.data && (response.data.console.length > 0 || response.data.network.length > 0)) {
            const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(response.data, null, 2));
            const downloadAnchorNode = document.createElement('a');
            downloadAnchorNode.setAttribute("href", dataStr);
            downloadAnchorNode.setAttribute("download", `logs-${new Date().toISOString()}.json`);
            document.body.appendChild(downloadAnchorNode);
            downloadAnchorNode.click();
            downloadAnchorNode.remove();
        } else {
            alert('No logs captured yet or logs are empty.');
        }
    });
});

copyLogBtn.addEventListener('click',() =>{
 // 1. Request the logs from the background script
  chrome.runtime.sendMessage({ type: 'GET_LOGS' }, (response) => {
    if (!response || !response.data || (response.data.console.length === 0 && response.data.network.length === 0)) {
      alert('No logs to copy.');
      return;
    }

    // 2. Format the logs into a nicely-indented JSON string
    const logString = JSON.stringify(response.data, null, 2);

    // 3. Use the Clipboard API to copy the string
    navigator.clipboard.writeText(logString).then(() => {
      // Success! Provide feedback to the user.
      const originalText = copyBtn.textContent;
      copyBtn.textContent = 'Copied!';
      copyBtn.style.backgroundColor = '#28a745'; // Green
      setTimeout(() => {
        copyBtn.textContent = originalText;
        copyBtn.style.backgroundColor = ''; // Revert style
      }, 2000); // Revert after 2 seconds
    }).catch(err => {
      // Failure
      console.error('Failed to copy logs: ', err);
      alert('Could not copy logs to clipboard. See the console for details.');
    });
  });
});


clearBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'CLEAR_LOGS' }, () => {
        alert('Logs cleared!');
    });
});