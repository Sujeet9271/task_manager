// This script runs in the MAIN world.

// --- Function to dispatch logs back to the content script ---
function dispatchLog(logData) {
    try {
        window.dispatchEvent(new CustomEvent('__LOG_CAPTURED__', { detail: logData }));
    } catch (e) {
        // Fallback if event dispatching fails for some reason
        console.log("Log Capturer Injector: Failed to dispatch log event.", e);
    }
}

// --- 1. CAPTURE UNCAUGHT EXCEPTIONS ---
window.addEventListener('error', function(event) {
    dispatchLog({
        level: 'uncaught-exception',
        args: [
            `Error: ${event.message}`,
            `Source: ${event.filename}:${event.lineno}:${event.colno}`,
            `Stack: ${event.error ? event.error.stack : 'N/A'}`
        ],
        timestamp: new Date().toISOString()
    });
    // We do NOT call event.preventDefault() so that the error still appears in the browser's console as normal.
});

// --- 2. CAPTURE UNHANDLED PROMISE REJECTIONS ---
window.addEventListener('unhandledrejection', function(event) {
    const reason = event.reason || {};
    dispatchLog({
        level: 'unhandled-rejection',
        args: [
            `Reason: ${reason.message || 'No message provided.'}`,
            `Stack: ${reason.stack || 'N/A'}`
        ],
        timestamp: new Date().toISOString()
    });
});


// --- 3. OVERRIDE CONSOLE METHODS (Existing Code) ---
const originalConsole = {};
const consoleMethods = ['log', 'warn', 'error', 'info', 'debug'];

function serializeForEvent(data) {
  if (data instanceof Error) return `[Error: ${data.message}]`;
  if (typeof data === 'object' && data !== null) {
      try { JSON.stringify(data); return data; } catch (e) { return '[Unserializable Object]'; }
  }
  return data;
}

function overrideConsoleMethod(level) {
  return (...args) => {
    // First, call the original console method
    if (originalConsole[level]) {
      originalConsole[level].apply(console, args);
    }
    // Then, dispatch our log event
    dispatchLog({
        level: level,
        args: args.map(serializeForEvent),
        timestamp: new Date().toISOString()
    });
  };
}

// Store originals before overriding
consoleMethods.forEach(level => {
  if (console[level]) {
    originalConsole[level] = console[level];
    console[level] = overrideConsoleMethod(level);
  }
});