// This script runs in the ISOLATED world by default.

console.log('Log Capturer: Content script loaded. Injecting main-world script.');

// Create a <script> tag to inject our injector.js into the page's main world
const s = document.createElement('script');
s.src = chrome.runtime.getURL('injector.js');
(document.head || document.documentElement).appendChild(s);

// Clean up the script tag once it's been added
s.onload = function() {
    this.remove();
};

// Listen for the custom event from the main-world script
window.addEventListener('__LOG_CAPTURED__', function(event) {
  // Now we are back in the isolated world, where chrome.runtime is safe.
  chrome.runtime.sendMessage({
    type: 'CONSOLE_LOG',
    payload: event.detail
  });
});